package com.uts.jwp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwpApplicationTests {

	@Test
	void contextLoads() {
	}

}
